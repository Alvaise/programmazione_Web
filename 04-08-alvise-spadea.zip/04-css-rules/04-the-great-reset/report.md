report
I have copy and pasted a previous exercise on which I had applied css rules.
So, for comparison every styles.css is the same for all three files.
I have applied like 10 rules on the three index files. 
The one that i think at the moment and given my level of knowledge and skill in web developing
is normalize because achieve basically the same thing as the other two but with less rules that i have to apply.
Perhaps in the future reset and destyle will be more useful as my skill progress and i gain more control over how to properly implement CSS rules.