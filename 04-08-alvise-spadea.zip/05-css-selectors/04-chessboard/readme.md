In the index.html i've created the table i've put letter inside the td for mark where the table was before applying any css rules.
In the Style. css i managed to do the exercise using three rules using relational selector. 
After applying the usual normalize rules.
The first step was applying width and height to the td element to make them square. Then set the background color of all the td black.
The second Step i used relational selector to select in all the odd td element of the odd tr element within the tbody(basically all the table) and applying the orange background color
In the third step i've done the opposite, select all the even td element of the even tr element within the tbody and applied the same color.
With basically three rules i've managed to get the pattern color of a 8x8 chessboard right.