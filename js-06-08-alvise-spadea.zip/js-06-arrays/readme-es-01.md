Your Top Choices.
Exercise on array
The Task was to make an array with my favorite choices and make a log to the console like this 'My ${nth}# choice is ${thing that i like}'. To achieve this first i made an array with my favorite things than i made a for cycle to log every element of the array with their relative position.
I didn't have any particular trouble in this part.
I improved the code by adding the correct english grammar for every position 1st,2nd,3rd,nth.
To achieve this i made another array with the suffixes, then a for cycle with a condition that attached for the first three element of the array the correct suffix.
In this part i had some problem to not make log the 'th' suffix so i added another if to apple the 'th' only to the element beyond the third.
This code could be problematic if the array of favorite thing is more than 10 element. 